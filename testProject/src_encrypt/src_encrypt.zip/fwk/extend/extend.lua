--------------------------------------------------------------------------------------
-- lua语言本身的扩展
-- @module fwk.extend
-- @author liuyang
-- @copyright liuyang 2019
-- @date 2019-01-24
-- @local
--------------------------------------------------------------------------------------

require "fwk.extend.string"
require "fwk.extend.table"